#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

const int MAX_WRONG_GUESSES = 6;

class HangmanGame {
private:
    std::string secretWord;
    std::string guessedWord;
    int wrongGuesses;
    std::vector<char> guessedLetters;

public:
    HangmanGame(const std::string& word) : secretWord(word), guessedWord(word.length(), '_'), wrongGuesses(0) {}

    bool isGameOver() const {
        return wrongGuesses >= MAX_WRONG_GUESSES || guessedWord == secretWord;
    }

    void displayHangman() const {
        std::cout << "Wrong guesses: " << wrongGuesses << "/" << MAX_WRONG_GUESSES << "\n";
        // Draw hangman figure here
    }

    void displayGuessedWord() const {
        std::cout << "Guessed word: " << guessedWord << "\n";
    }

    void displayGuessedLetters() const {
        std::cout << "Guessed letters: ";
        for (char letter : guessedLetters) {
            std::cout << letter << " ";
        }
        std::cout << "\n";
    }

    void guessLetter(char letter) {
        if (std::find(guessedLetters.begin(), guessedLetters.end(), letter) != guessedLetters.end()) {
            std::cout << "You already guessed that letter.\n";
            return;
        }

        guessedLetters.push_back(letter);

        bool found = false;
        for (int i = 0; i < secretWord.length(); ++i) {
            if (secretWord[i] == letter) {
                guessedWord[i] = letter;
                found = true;
            }
        }

        if (!found) {
            ++wrongGuesses;
        }
    }

    void play() {
        std::cout << "Welcome to Hangman!\n";

        while (!isGameOver()) {
            displayHangman();
            displayGuessedWord();
            displayGuessedLetters();

            char guess;
            std::cout << "Enter a letter guess: ";
            std::cin >> guess;

            guessLetter(guess);
        }

        displayHangman();
        displayGuessedWord();

        if (guessedWord == secretWord) {
            std::cout << "Congratulations! You guessed the word: " << secretWord << "\n";
        } else {
            std::cout << "Sorry, you're out of guesses. The word was: " << secretWord << "\n";
        }
    }
};

int main() {
    std::string word;
    std::cout << "Player 1, enter a word for Hangman: ";
    std::cin >> word;

    HangmanGame game(word);
    game.play();

    return 0;
}
